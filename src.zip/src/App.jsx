import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import {SignIn, SignUp, HomePage, Cart, Checkout,
  Products, SingleProduct,  PageNotFound, 
  AdminHome, ViewProducts, CreateProduct, UpdateProduct} from './Pages/index.jsx'

function App() {

  return (
    <>
     <Router>
       <Routes>
          <Route path='/sign-up' element={<SignUp/>} exact/>          
          <Route path='/sign-in' element={<SignIn/>} />
          <Route path='/' element={<HomePage/>} exact/>
          <Route path='/cart' element={<Cart/>} exact/>
          <Route path='/checkout' element={<Checkout/>} exact/>
          <Route path='/products' element={<Products/>} exact/>
          <Route path='/product/:id' element={<SingleProduct/>} exact/>


          <Route path='/*' element={<PageNotFound/>} exact/>

          <Route path='/admin' element={<AdminHome/>} exact/>
          <Route path='/admin/view-products' element={<ViewProducts/>} exact/>
          <Route path='/admin/create-product' element={<CreateProduct/>} exact/>
          <Route path='/admin/update-product/:id' element={<UpdateProduct/>} exact/>

          
       </Routes>
    </Router> 
  </>
  )
}

export default App
