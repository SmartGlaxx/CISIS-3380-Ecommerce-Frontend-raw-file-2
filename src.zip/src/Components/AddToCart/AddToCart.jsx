import React, { useState } from 'react'
import { UseAppContext } from '../../Contexts/app-context'
import { Link } from 'react-router-dom'
import { Alert } from '@mui/material'

const AddToCart = ({product, selectedColor}) => {
  let [quantity, setQuantity] = useState(0)
  const [alert, setAlert] = useState(false)
  const {addToCart} = UseAppContext()
  const {_id, productName, inventory} = product

  const decrease = ()=>{
    if(quantity <= 1){
        setQuantity(1)
    }else{
        quantity--
        setQuantity(quantity)
    }
  }
  const increase = ()=>{
    if(quantity == inventory){
        setQuantity(inventory)
    }else{
        quantity++
        setQuantity(quantity)
    }
    
  }

  const addItemToCart = (_id, productName, selectedColor, quantity, product)=>{
    if(!selectedColor){
      setAlert({status: true, msg: "Select a color"})
      setTimeout(()=>{
        setAlert({status: false, msg: ""})
      }, 4000)
    }else{
      addToCart(_id, productName, selectedColor, quantity, product)
    }
  }

  return (
    <div>
        {
            alert.status && <div className='product-alert' >
            <Alert severity="error">{alert.msg}</Alert>
          </div>
        }
        {product.inventory}
        {selectedColor}
        <div>
            <button onClick={()=>decrease()}>-</button>
            {quantity}
            <button onClick={()=>increase()}>+</button>
        </div>
        <Link to={`/cart`}><button>Go to cart</button></Link>
        <button onClick={()=>addItemToCart(_id, productName, selectedColor, quantity, product)}>Add to cart</button>
    </div>
  )
}

export default AddToCart