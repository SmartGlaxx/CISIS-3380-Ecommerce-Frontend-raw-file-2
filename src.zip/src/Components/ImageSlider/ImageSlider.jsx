import React, { useEffect, useState } from 'react';
import './ImageSlider.css';

const ImageSlider = ({ images }) => {
  const [selectedImage, setSelectedImage] = useState(images[0]);

  const handleImageClick = (newImage) => {
    setSelectedImage(newImage);
  };

  useEffect(()=>{
    setSelectedImage(images[0])
  },[images])

  return (
    <div className="image-slider">
      <div className="primary-image">
        <img src={selectedImage} alt="Primary" />
      </div>
      <div className="secondary-images">
        {images.map((image, index) => (
          <img
            key={index}
            src={image}
            alt={`img_${index}`}
            onClick={() => handleImageClick(image)}
            className={image == selectedImage && "active-image"}
          />
        ))}
      </div>
    </div>
  );
};

export default ImageSlider;
