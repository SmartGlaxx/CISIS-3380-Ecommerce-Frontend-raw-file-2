import React from 'react'
import { UseAppContext } from '../../Contexts/app-context'
import "./ProductViews.css"
import {formattedPrice} from "../../resourses/functions.jsx"
import { Link } from 'react-router-dom'

const GridView = () => {
    const {filteredProducts, sort} = UseAppContext()
  
    return (
    <div className='grid-view'>
        {filteredProducts.length > 0 ? filteredProducts.map(product =>{
            const {_id, productName, price, productImages, freeShipping} = product
            return<Link to={`/product/${_id}`}  className='gridview-product' key={_id}>
                <img src={productImages[0]} alt={`img_${_id}`} className='gridview-product-image'/>
                <div className='gridview-product-name'>{productName}</div>
                <div className='gridview-product-price'>{formattedPrice(price)}</div>
                <div>Free shipping: {freeShipping? "Yes": "No"}</div>
                </Link>
        }): <div>No items match your search...</div>}
    </div>
  )
}

export default GridView