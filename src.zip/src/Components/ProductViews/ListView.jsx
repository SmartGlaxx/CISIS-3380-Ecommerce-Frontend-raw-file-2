import React from 'react'
import { UseAppContext } from '../../Contexts/app-context'
import "./ProductViews.css"
import {formattedPrice} from "../../resourses/functions.jsx"
import { Link } from 'react-router-dom'

const ListView = () => {
    const {filteredProducts} = UseAppContext()
  
    return (
    <div className='list-view'>
        {filteredProducts.length > 0 ? filteredProducts.map(product =>{
            const {_id, productName, price, description, productImages, freeShipping} = product
            return<Link to={`/product/${_id}`}  className='listview-product' key={_id}>
            <img src={productImages[0]} alt={`img_${_id}`} className='listview-product-image'/>
            <div className='listview-product-name'>{productName}</div>
            <div className='listview-product-price'>{formattedPrice(price)}</div>
            <div className='listview-description'>{description}</div>
            <div>Free shipping: {freeShipping? "Yes": "No"}</div>
            </Link>
        }) : <div>No items match your search...</div>}
    </div>
  
  )
}

export default ListView