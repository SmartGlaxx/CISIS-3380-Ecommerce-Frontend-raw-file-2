import React, { useState, useEffect } from 'react';
import { Link, Navigate } from 'react-router-dom';
import axios from 'axios';
import "./ViewProducts.css"
import AdminHome from "../AdminHome/AdminHome"
import { Button } from '@mui/material';
import Alert from '@mui/material/Alert';
import { UseAppContext } from '../../../Contexts/app-context';

const ViewProducts = () => {
  const {loggedIn, currentUserParsed, products, loading, alert, setAlert
  } = UseAppContext()
  // const [products, setProducts] = useState([]);
  // const [alert, setAlert] = useState({status: false, message: ""})
  const [error, setError] = useState({status: false, message: ""})
  const {role} = currentUserParsed
  
  // const fetchProducts = async()=>{
  //     await axios.get('http://localhost:5001/products/all')
  //     .then((response) => setProducts(response.data.products))
  //     .catch((error) => console.error('Error fetching products:', error));
  // }
  // useEffect(() => {
  //   fetchProducts()
  // }, []);

    const deleteProduct = async (id) => {
      try {
        const result = await axios.delete(`http://localhost:5000/products/delete/${id}`);
        const {response, message} = result.data

        if (response === 'Success') {
          setAlert({status: true, message: message})
          setTimeout(() => {
            setAlert({status: false, message: ''})
          }, 4000)
          fetchProducts()
        } else {
          setAlert({status: true, message: message})
          setTimeout(() => {
            setAlert({status: false, message: ''})
          }, 4000)
        }
      } catch (error) {
      setAlert({status: true, message: error.message})
        setTimeout(() => {
          setAlert({status: false, message: ''})
        }, 4000)
      }
    };

    useEffect(() => {
      const timer = setTimeout(() => {
        if (loggedIn === "false" || role !== "admin") {
          return  <Navigate to='/' /> 
        }
      }, 2000); 
      return () => clearTimeout(timer);
    }, []); 


    if(loading == true){
      return <div>
        <AdminHome />
        <div style={{textAlign: "center", marginTop: "15rem"}}>Loading</div>
        </div>
    }

  return (
    <>
    <AdminHome />
    <div className="view-products">
      {
        alert.status && <div className='admin-alert'>
          <Alert severity="error">{alert.msg}</Alert>
        </div>
      }
      { products.length > 0 && <><h1 className='view-product-title'>Product List</h1>

      <div className="products-container">
        {products.map((product) => (
          <div key={product._id} className="product-card">
            <img
              src={product.productImages.length > 0 ? product.productImages[0] : ''}
              alt={`img_${product._id}`} 
              className="thumbnail"
            />
            <h3 className='product-name'>{product.productName}</h3>
            <p>${product.price}</p>
            <p className='product-description'>{product.description}</p>
            <p>Category: {product.productCategory}</p>
            <p>Manufacturer: {product.manufacturer}</p>
            <p>Colors: {product.colors.join(', ')}</p>
            <p>Featured: {product.featured ? 'Yes' : 'No'}</p>
            <p>Free Shipping: {product.freeShipping ? 'Yes' : 'No'}</p>
            <p>Inventory: {product.inventory}</p>

            <div className="action-buttons">
              <Link to={`/admin/update-product/${product._id}`} className="update-button">
                Update
              </Link>
              <Link to='' className="delete-button" onClick={()=>deleteProduct(product._id)}>
                Delete
              </Link>
            </div>
          </div>
        ))}
      </div></>}
    </div>
    </>
  );
};

export default ViewProducts;
