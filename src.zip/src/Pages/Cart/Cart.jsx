import React from 'react'
import { Navbar, Sidebar, Footer, Backdrop} from '../../Components'
import { UseAppContext } from '../../Contexts/app-context'
import "./Cart.css"
import { formattedPrice } from '../../resourses/functions'
import { Link } from 'react-router-dom'

const Cart = () => {
  const {loggedIn, currentUserParsed, cart} = UseAppContext()
  let total = 0
  return (
    <div>
      
      <Navbar />
      <Sidebar />
      <Backdrop />
      {loggedIn == "true" ?
      <div className='cart'>
        <h3>Cart</h3>
        {
          
          cart.length > 0 ? 
          <div >
          {
          cart.map(cartItem=>{
            const {id, productName, selectedColor, quantity, inventory, image, price} = cartItem
            
            total += (quantity * price)
            return <div className='cart-item' >
              <img src={image} alt={`img_${id}`} className='cart-image'/>
              <h4 className='cart-product-name'>{productName}</h4>
              <div className='cart-product-color'>Color: <div style={{background: `${selectedColor}`}} 
              className='cart-color'></div>{selectedColor}</div>
              <div className='cart-product-quntity'>Quantity: {quantity}</div>
              <div className='cart-product-inventory'>Available: {inventory}</div>
              <div className='cart-product-price'>Unit price: <span className='cart-product-price-2'>{formattedPrice(price)}</span></div>
              <div className='cart-product-subtotal'>Sub total: <span className='cart-product-subtotal-2'>{formattedPrice(price * quantity)}</span></div>
              {/* <hr /> */}
            </div>
          })
        }

          <div className='cart-total'>Total: {formattedPrice(total)}</div>
          
          <div className='cart-option-buttons'>
            <Link to={"/products"}><button className='continue-shopping'>Continue shopping</button></Link>
            <button className='pay-button'>Pay {formattedPrice(total)}</button>
          </div>
          </div>
          : <div><div className='empty-cart'>Your cart is empty. 
            <Link to={`/products`} className='empty-cart-link'>Start shopping</Link>
          </div></div>
        }
      </div>
    : <div>Log in</div>}
      <Footer />
      </div>

  )
}

export default Cart