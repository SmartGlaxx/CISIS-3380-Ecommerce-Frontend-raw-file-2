
import React from 'react';
import { Grid } from '@mui/material';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import image1 from "../../../assets/images/slideshow/camera-electronics1.jpg";
import image2 from "../../../assets/images/slideshow/fashion-boot4.jpg";
import image3 from "../../../assets/images/slideshow/fashion-cardigan1.jpg";
import image4 from "../../../assets/images/slideshow/fashion-shirt5.jpg";
import image5 from "../../../assets/images/slideshow/laptop-electonics3.jpg";
import image6 from "../../../assets/images/slideshow/electronics-watch5.jpg";

const HeroSection = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
  };

  return (
    <Slider {...settings} className="hero-carousel">
      <div className="carousel-slide">
        <div className="carousel-text" style={{  background: `url(${image1})`, backgroundSize: 'cover' }}>
          <div>
            <h1>Slide 1 Title</h1>
            <p>Description for Slide 1</p>
          </div>
        </div>
      </div>
      <div className="carousel-slide">
        <div className="carousel-text" style={{  background: `url(${image2})`, backgroundSize: 'cover' }}>
          <div>
            <h1>Slide 2 Title</h1>
            <p>Description for Slide 2</p>
          </div>
        </div>
      </div>
      <div className="carousel-slide">
        <div className="carousel-text" style={{  background: `url(${image3})`, backgroundSize: 'cover' }}>
          <div>
            <h1>Slide 3 Title</h1>
            <p>Description for Slide 3</p>
          </div>
        </div>
      </div>
      <div className="carousel-slide">
        <div className="carousel-text" style={{  background: `url(${image4})`, backgroundSize: 'cover' }}>
          <div>
            <h1>Slide 4 Title</h1>
            <p>Description for Slide 4</p>
          </div>
        </div>
      </div>
      <div className="carousel-slide">
        <div className="carousel-text" style={{  background: `url(${image5})`, backgroundSize: 'cover' }}>
          <div>
            <h1>Slide 5 Title</h1>
            <p>Description for Slide 5</p>
          </div>
        </div>
      </div>
      <div className="carousel-slide">
        <div className="carousel-text" style={{  background: `url(${image6})`, backgroundSize: 'cover' }}>
          <div>
            <h1>Slide 6 Title</h1>
            <p>Description for Slide 6</p>
          </div>
        </div>
      </div>
    </Slider>
  );
};

export default HeroSection;
