import SignUp from "./authentication/SignUp/signup";
import SignIn from "./authentication/SignIn/SignIn";
import HomePage from "./HomePage/HomePage";
import Cart from "./Cart/Cart";
import Checkout from "./Checkout/Checkout";
import Products from "./Products/Products";
import SingleProduct from "./SingleProduct/SingleProduct";

import PageNotFound from "./PageNotFound/PageNotFound";

import AdminHome from "./Administrator/AdminHome/AdminHome"
import ViewProducts from "./Administrator/ViewProducts/ViewProducts"
import CreateProduct from "./Administrator/CreateProduct/CreateProduct";
import UpdateProduct from "./Administrator/UpdateProduct/UpdateProduct";


export {SignIn, SignUp, HomePage, Cart, Checkout,
Products, SingleProduct,  PageNotFound, 
AdminHome, ViewProducts, CreateProduct, UpdateProduct}