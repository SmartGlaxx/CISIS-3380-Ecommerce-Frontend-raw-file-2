export const formattedPrice = (price) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(price);
};

export const uniqueValues = (data, type)=>{
  let unique = data.map(item => item[type])
  if(type == "colors"){
    unique = unique.flat()
  }
  return ["All", ...new Set(unique)]
}

export const capitalizeFirstLetter=(str)=>{
  return str.charAt(0).toUpperCase() + str.slice(1);
}