import { FaHouse, FaTableCells, FaCartShopping } from "react-icons/fa6"
export const links = [
    {
        id: 1,
        name: "Homepage",
        url: "/",
        icon: <FaHouse />,
        color: "green"
    },
    {
        id: 2,
        name: "Products",
        url: "/products",
        icon: <FaTableCells />,
        color: "blue"
    },
    {
        id: 3,
        name: "Cart",
        url: "/cart",
        icon: <FaCartShopping />,
        color: "red"
    }
]